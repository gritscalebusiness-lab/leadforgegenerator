-- 1. Maak een nieuwe tabel met alle kolommen die de app nodig heeft
CREATE TABLE users_new (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    plan TEXT DEFAULT 'basic',
    search_count INTEGER DEFAULT 0,
    quota_limit INTEGER DEFAULT 100,
    onboarding_seen INTEGER DEFAULT 0,
    team_id TEXT,
    is_admin INTEGER DEFAULT 0,
    company_id TEXT
);

-- 2. Kopieer bestaande gebruikers (kolommen die al bestonden)
INSERT INTO users_new (id, username, email, password, plan, search_count, quota_limit, onboarding_seen, team_id, is_admin)
SELECT id, username, email, password,
       COALESCE(plan, 'basic'),
       COALESCE(search_count, 0),
       COALESCE(quota_limit, 100),
       COALESCE(onboarding_seen, 0),
       team_id,
       COALESCE(is_admin, 0)
FROM users;

-- 3. Oude tabel verwijderen
DROP TABLE users;

-- 4. Nieuwe tabel hernoemen
ALTER TABLE users_new RENAME TO users;

