import sqlite3
from werkzeug.security import generate_password_hash

# Database pad
DB_PATH = "site.db"

# Admin/co-founder accounts die je wil toevoegen of updaten
ADMINS = [
    {
        "username": "admin",
        "email": "linearfncs@gmail.com",
        "password": "Bowlen15",
        "role": "admin",
        "team_id": 1
    },
    {
        "username": "cofounder1",
        "email": "cofounder1@example.com",
        "password": "TestPass123",
        "role": "admin",
        "team_id": 1
    },
    {
        "username": "cofounder2",
        "email": "cofounder2@example.com",
        "password": "AnotherPass456",
        "role": "admin",
        "team_id": 1
    }
]

# Verbinden met database
conn = sqlite3.connect(DB_PATH)
c = conn.cursor()

# Zorg dat users tabel bestaat
c.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    email TEXT UNIQUE,
    password TEXT,
    role TEXT DEFAULT 'user',
    team_id INTEGER DEFAULT NULL
)
""")

# Verwerk elke admin
for admin in ADMINS:
    hashed_pw = generate_password_hash(admin["password"], method="pbkdf2:sha256")

    c.execute("SELECT id FROM users WHERE email = ?", (admin["email"],))
    user = c.fetchone()

    if user:
        # Updaten
        c.execute("""
            UPDATE users
            SET username=?, password=?, role=?, team_id=?
            WHERE email=?
        """, (admin["username"], hashed_pw, admin["role"], admin["team_id"], admin["email"]))
        print(f"🔄 Account bijgewerkt: {admin['email']}")
    else:
        # Aanmaken
        c.execute("""
            INSERT INTO users (username, email, password, role, team_id)
            VALUES (?, ?, ?, ?, ?)
        """, (admin["username"], admin["email"], hashed_pw, admin["role"], admin["team_id"]))
        print(f"✅ Account aangemaakt: {admin['email']}")

conn.commit()
conn.close()

