# LeadForge - Lead Generation SaaS Platform

## Overview

LeadForge is a Python-based SaaS application for B2B lead generation and management. The platform enables users to search for business leads, score them using AI, manage teams, export data to various formats, and integrate with CRM systems. It features a tiered subscription model (Basic/Business/Enterprise) with Stripe payment processing.

The application is built with Flask using a modern application factory pattern and uses PostgreSQL for data persistence in production (SQLite for development). It provides lead scraping capabilities (via SerpAPI/Google Maps), AI-powered lead scoring, export functionality (CSV/Excel/CRM), team collaboration features, and analytics dashboards.

## Recent Changes

**November 14, 2025 - Production-Grade Restructure & Security Hardening**
- Reorganized entire codebase into production-ready structure with proper separation of concerns
- Implemented Flask application factory pattern for better testability and configuration management
- Migrated from raw SQLite queries to SQLAlchemy ORM with Flask-SQLAlchemy
- Created modular blueprint architecture: auth, leads, teams, payments, main
- Moved templates and static files into app/ directory
- Added comprehensive configuration management with environment-based configs
- Updated all templates to use blueprint-aware url_for() calls
- Installed psycopg2-binary for PostgreSQL support
- Added proper .gitignore for Python projects
- Created migrations/ and tests/ directories for future use

**November 14, 2025 - Security Hardening & Dual Payment Integration**
- Implemented comprehensive security hardening with Flask-WTF (CSRF), Flask-Limiter (rate limiting), Flask-Talisman (secure headers)
- Migrated password hashing from Werkzeug to bcrypt for stronger security
- Added input validation and sanitization to all authentication routes
- Configured Content Security Policy (CSP) to allow Stripe and PayPal JavaScript SDKs
- Integrated PayPal payment system alongside Stripe for dual payment provider support
- Created ConsumedPayment model to prevent payment token reuse attacks
- Implemented server-side payment validation: email verification, amount verification, status checks
- Added payment provider tracking fields to User model (stripe_customer_id, paypal_subscription_id, payment_provider)
- Disabled legacy confirm_upgrade bypass route to prevent free upgrades
- Added comprehensive logging for security events (payment reuse attempts, email mismatches)
- Updated error handlers to properly pass current_user context to templates

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Web Framework & Application Structure
- **Flask-based monolithic architecture** with blueprint-based route organization
- Application factory pattern in `app/__init__.py` creates Flask instances with environment-specific configurations
- Blueprints separate concerns: `auth_bp`, `leads_bp`, `teams_bp`, `payments_bp`, `main_bp`
- Server-side template rendering using Jinja2
- Static files and templates served from `app/static/` and `app/templates/`

**Rationale**: Flask provides simplicity and flexibility for a mid-sized SaaS application. The blueprint structure allows modular development and easier testing. This approach was chosen over microservices to reduce operational complexity for an early-stage product.

### Database & ORM
- **SQLAlchemy ORM** with Flask-SQLAlchemy extension
- **PostgreSQL database** in production (Replit Postgres); SQLite (`database.db`) for local development
- Flask-Migrate (Alembic) handles schema migrations
- Models organized in `app/models/` directory
- Primary model: `User` with fields for authentication, subscription plans, quotas, team membership, and usage tracking

**Rationale**: SQLAlchemy provides database abstraction and easier query construction. PostgreSQL provides better concurrency and scalability for production. The ORM allows for easy migration between database engines using DATABASE_URL configuration.

### Authentication & Session Management
- **Flask-Login** for session-based authentication
- **bcrypt** password hashing (12 rounds) replacing Werkzeug for stronger security
- **Flask-WTF** CSRF protection on all state-changing routes
- **Flask-Limiter** rate limiting: 5 attempts/minute on auth routes, 10/hour on payment routes
- Input validation and sanitization for email, password, and username fields
- Login required decorator protects routes
- User sessions stored server-side with Flask's secure cookie mechanism

**Rationale**: bcrypt provides stronger, adaptive password hashing. CSRF tokens prevent cross-site attacks. Rate limiting mitigates brute force attacks. Input validation prevents injection attacks. Session-based auth chosen over JWT for simpler implementation and built-in security.

### Subscription & Payment Processing
- **Dual payment provider support**: Stripe and PayPal REST API integration
- Three-tier pricing: Basic (free), Business (€79/month), Enterprise (€199/month)
- **Stripe Checkout Sessions** for card payments with plan metadata tracking
- **PayPal REST API** (Orders v2) for PayPal payments with server-side order creation/capture
- **ConsumedPayment model** prevents payment token reuse across accounts
- **Server-side validation**: email verification, payment amount verification, payment status checks
- User model tracks `plan`, `quota_limit`, `search_count`, `payment_provider`, provider-specific IDs
- Monthly quota reset logic using `last_reset` timestamp field
- VALID_PLANS dictionary ensures server-side plan-to-amount mapping
- Disabled legacy confirm_upgrade route to prevent unauthorized upgrades

**Rationale**: Dual payment providers increase conversion by offering customer choice. Server-side validation prevents payment bypass attacks. ConsumedPayment tracking prevents token reuse. Metadata tracking enables proper plan validation. Stripe and PayPal provide secure, PCI-compliant processing.

### Lead Generation & Scraping
- **SerpAPI** (Google Maps engine) for business search queries
- Search parameters: query term, location, language (Dutch)
- Results include business name, address, website, contact details
- Mock/placeholder implementation in current codebase for development

**Rationale**: SerpAPI provides reliable access to Google Maps business data without violating ToS. The API-based approach is more maintainable than custom scrapers. Mock data allows development without API costs.

### AI Lead Scoring
- Simple rule-based scoring algorithm in `app/services/ai_scoring.py`
- Scores based on data completeness (website presence, email availability)
- Returns score 0-100 for lead quality assessment

**Rationale**: Current implementation is a placeholder for future ML-based scoring. Rule-based approach provides immediate value while gathering training data for proper AI models. Scoring service is isolated for easy replacement.

### Data Export
- **CSV export** using Python's csv module
- **Excel export** via pandas and openpyxl
- **CRM integration** planned for HubSpot, Salesforce, Pipedrive (Enterprise tier)
- Export service abstracted in `app/services/export_service.py`

**Rationale**: Multiple export formats serve different user workflows. CSV for simplicity, Excel for business users, CRM for automation. Service layer architecture enables adding new export formats without touching route logic.

### Team Management
- Team-based access control for Business/Enterprise tiers
- `team_id` field associates users with teams
- `is_admin` flag for team ownership/permissions
- Team invite system via email lookup

**Rationale**: Team functionality is a key differentiator for paid tiers. The simple team_id approach scales to small/medium teams without complex ACL systems. Admin flag provides basic role-based permissions.

### Frontend Architecture
- Server-side rendering with Jinja2 templates
- Custom CSS in `app/static/style.css` with CSS variables for theming
- Aqua/blue color scheme for branding
- No JavaScript framework; vanilla JS for interactive elements
- Chart.js for analytics visualizations

**Rationale**: SSR reduces frontend complexity and improves SEO. No build process simplifies deployment. Custom CSS provides brand identity without framework bloat. Chart.js chosen for lightweight, feature-rich charting.

### Security Architecture
- **Flask-Talisman** enforces secure HTTP headers (HSTS, X-Frame-Options, X-Content-Type-Options)
- **Content Security Policy (CSP)** configured to allow Stripe and PayPal JavaScript SDKs
- **CSRF protection** via Flask-WTF on all POST/PUT/DELETE routes
- **Rate limiting** via Flask-Limiter: 5/min auth routes, 10/hour payment routes
- **bcrypt password hashing** with salt (12 rounds)
- **Input validation** on all user-supplied data (email format, password strength, username length)
- **Payment security**: email verification, amount validation, token reuse prevention
- **Security logging** for suspicious activities (payment reuse, email mismatches)

**Rationale**: Defense-in-depth security strategy. CSP prevents XSS attacks. CSRF tokens prevent cross-site attacks. Rate limiting mitigates brute force. bcrypt provides adaptive security. Payment validation prevents fraud. Logging enables security monitoring.

### Configuration Management
- Environment-based configuration classes in `app/config/`
- Development, Production, Testing configs extend base Config class
- **python-dotenv** loads environment variables from `.env` file
- Sensitive credentials (Stripe keys, PayPal keys, API keys) stored in environment variables
- PayPal configuration supports sandbox/production modes

**Rationale**: Class-based config enables environment-specific settings. Dotenv simplifies local development. Environment variables follow 12-factor app methodology for production deployments. Separate sandbox/production modes enable safe testing.

### Error Handling & Monitoring
- **Sentry SDK** integration for error tracking (configured but DSN optional)
- Custom 404 and 500 error pages
- Flash messages for user feedback
- Graceful handling when Sentry DSN missing

**Rationale**: Sentry provides production error monitoring and debugging. Custom error pages maintain UX during failures. Flash messages give immediate user feedback without JavaScript.

## External Dependencies

### Third-Party APIs
- **SerpAPI** - Google Maps business search results (API key in test files)
- **Stripe** - Card payment processing (secret and publishable keys in config)
- **PayPal REST API** - PayPal payment processing (client ID, secret, mode in config)
- **Google Sheets API** - Planned integration via gspread/oauth2client (credentials.json present)
- **HubSpot/Salesforce/Pipedrive** - CRM integrations (Enterprise feature, not yet implemented)

### Python Libraries
- **Flask 2.3.2** - Web framework
- **Flask-Login 0.6.3** - Authentication
- **Flask-SQLAlchemy 3.0.5** - ORM
- **Flask-Migrate 4.0.5** - Database migrations
- **Flask-WTF 1.2.1** - CSRF protection
- **Flask-Limiter 3.5.0** - Rate limiting
- **Flask-Talisman 1.1.0** - Security headers (HSTS, CSP)
- **bcrypt 4.1.2** - Password hashing
- **Werkzeug 2.3.7** - WSGI utilities
- **Stripe 5.4.0** - Stripe payment API
- **PayPalRESTSDK** - PayPal payment API (or requests for REST API calls)
- **Pandas 2.0.3** - Data manipulation for exports
- **ReportLab 3.6.13** - PDF generation (future feature)
- **APScheduler 3.10.4** - Background job scheduling (likely for quota resets)
- **Sentry-SDK 1.29.2** - Error monitoring
- **Gunicorn 21.2.0** - Production WSGI server

### Database
- **PostgreSQL** - Production database (via DATABASE_URL environment variable)
- **SQLite** - Development fallback (file: `database.db`)
- **psycopg2-binary** - PostgreSQL adapter for Python

### Infrastructure Services
- Google Cloud Platform service account (credentials.json) for Sheets API access
- Stripe payment gateway for subscription billing
- Sentry.io for error tracking (optional)

### Development Tools
- Flask development server for local testing
- Flask-Migrate CLI for database schema changes
- Python-dotenv for local environment configuration