import sqlite3
import datetime

DB_FILE = "database.db"

with sqlite3.connect(DB_FILE) as conn:
    c = conn.cursor()
    try:
        c.execute(ALTER TABLE users ADD COLUMN onboarding_seen INTEGER DEFAULT 0;
)
        print("✅ Kolom 'onboarding seen' toegevoegd")
    except sqlite3.OperationalError:
        print("Kolom 'last_reset' bestaat al, niets te doen")

    # Zet alle bestaande users hun last_reset naar deze maand
    this_month = datetime.date.today().strftime("%Y-%m")
    c.execute("UPDATE users SET last_reset = ?", (this_month, ))
    conn.commit()

print("✅ Database bijgewerkt")
