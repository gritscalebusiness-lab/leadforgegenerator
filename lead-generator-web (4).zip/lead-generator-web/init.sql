DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS favorites;
DROP TABLE IF EXISTS notes;

CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    plan TEXT DEFAULT 'basic',
    quota_limit INTEGER DEFAULT 30,
    search_count INTEGER DEFAULT 0,
    team_id INTEGER,
    is_admin INTEGER DEFAULT 0,
    onboarding_seen INTEGER DEFAULT 0
);

CREATE TABLE favorites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    company_name TEXT,
    company_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    company_id INTEGER,
    note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

-- Voeg een standaard admin toe
INSERT INTO users (username, email, password, plan, quota_limit, is_admin)
VALUES (
    'admin',
    'linearfncs@gmail.com',
    '$pbkdf2-sha256$29000$U0VjcmV0S2V5SGFzaA$7LZr3vdpQ34uB6Q5XjscWfSkxCzFZVJfM5klf38q2ro', -- hash van Bowlen15
    'enterprise',
    9999,
    1
);

