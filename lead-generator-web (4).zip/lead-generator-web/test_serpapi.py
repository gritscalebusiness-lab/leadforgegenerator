from serpapi import GoogleSearch

params = {
    "engine": "google_maps",
    "q": "horeca Amsterdam",
    "hl": "nl",
    "api_key": "6ab382eb5849311dfd8936f1d5b66ece4ccc1d8eabc10b2ed3c1925f3bd4298d"
}

search = GoogleSearch(params)
results = search.get_dict()

print("Aantal resultaten:", len(results.get("local_results", [])))
