from flask_login import UserMixin
import bcrypt
from app.extensions import db


class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    plan = db.Column(db.String(50), default='basic')
    quota_limit = db.Column(db.Integer, default=30)
    search_count = db.Column(db.Integer, default=0)
    team_id = db.Column(db.String(100), nullable=True)
    is_admin = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    last_reset = db.Column(db.String(20), nullable=True)
    stripe_customer_id = db.Column(db.String(100), nullable=True)
    paypal_subscription_id = db.Column(db.String(100), nullable=True)
    payment_provider = db.Column(db.String(20), default='stripe')


    def set_password(self, password):
        salt = bcrypt.gensalt()
        self.password = bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

    def check_password(self, password):
        return bcrypt.checkpw(password.encode('utf-8'), self.password.encode('utf-8'))

    def __repr__(self):
        return f'<User {self.username}>'


class ConsumedPayment(db.Model):
    __tablename__ = 'consumed_payments'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    payment_id = db.Column(db.String(255), unique=True, nullable=False)
    provider = db.Column(db.String(20), nullable=False)
    plan = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    consumed_at = db.Column(db.DateTime, default=db.func.current_timestamp())
