import requests
import base64
from flask import current_app


def get_paypal_access_token():
    client_id = current_app.config.get('PAYPAL_CLIENT_ID')
    client_secret = current_app.config.get('PAYPAL_CLIENT_SECRET')
    api_base = current_app.config.get('PAYPAL_API_BASE')
    
    if not client_id or not client_secret:
        raise ValueError("PayPal credentials not configured")
    
    url = f"{api_base}/v1/oauth2/token"
    headers = {
        "Accept": "application/json",
        "Accept-Language": "en_US",
    }
    
    auth_string = f"{client_id}:{client_secret}"
    auth_bytes = auth_string.encode('ascii')
    auth_b64 = base64.b64encode(auth_bytes).decode('ascii')
    headers["Authorization"] = f"Basic {auth_b64}"
    
    data = {"grant_type": "client_credentials"}
    
    response = requests.post(url, headers=headers, data=data)
    
    if response.status_code == 200:
        return response.json()['access_token']
    else:
        raise Exception(f"Failed to get PayPal access token: {response.text}")


def create_paypal_order(amount, currency='EUR', description='LeadForge Subscription'):
    access_token = get_paypal_access_token()
    api_base = current_app.config.get('PAYPAL_API_BASE')
    
    url = f"{api_base}/v2/checkout/orders"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {access_token}"
    }
    
    payload = {
        "intent": "CAPTURE",
        "purchase_units": [{
            "amount": {
                "currency_code": currency,
                "value": str(amount)
            },
            "description": description
        }]
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code in [200, 201]:
        return response.json()
    else:
        raise Exception(f"Failed to create PayPal order: {response.text}")


def capture_paypal_order(order_id):
    access_token = get_paypal_access_token()
    api_base = current_app.config.get('PAYPAL_API_BASE')
    
    url = f"{api_base}/v2/checkout/orders/{order_id}/capture"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {access_token}"
    }
    
    response = requests.post(url, headers=headers)
    
    if response.status_code in [200, 201]:
        return response.json()
    else:
        raise Exception(f"Failed to capture PayPal order: {response.text}")


def verify_paypal_order(order_id):
    access_token = get_paypal_access_token()
    api_base = current_app.config.get('PAYPAL_API_BASE')
    
    url = f"{api_base}/v2/checkout/orders/{order_id}"
    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        order = response.json()
        return {
            "verified": order.get('status') == 'COMPLETED',
            "order": order
        }
    else:
        return {"verified": False, "error": response.text}


def create_paypal_subscription_plan(name, description, amount, currency='EUR', interval='MONTH'):
    access_token = get_paypal_access_token()
    api_base = current_app.config.get('PAYPAL_API_BASE')
    
    url = f"{api_base}/v1/billing/plans"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {access_token}",
        "Prefer": "return=representation"
    }
    
    payload = {
        "product_id": "PROD-LEADFORGE",
        "name": name,
        "description": description,
        "status": "ACTIVE",
        "billing_cycles": [{
            "frequency": {
                "interval_unit": interval,
                "interval_count": 1
            },
            "tenure_type": "REGULAR",
            "sequence": 1,
            "total_cycles": 0,
            "pricing_scheme": {
                "fixed_price": {
                    "value": str(amount),
                    "currency_code": currency
                }
            }
        }],
        "payment_preferences": {
            "auto_bill_outstanding": True,
            "setup_fee": {
                "value": "0",
                "currency_code": currency
            },
            "setup_fee_failure_action": "CONTINUE",
            "payment_failure_threshold": 3
        }
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code in [200, 201]:
        return response.json()
    else:
        raise Exception(f"Failed to create PayPal subscription plan: {response.text}")
