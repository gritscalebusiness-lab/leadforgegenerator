import secrets


def create_team_id():
    return secrets.token_hex(8)
