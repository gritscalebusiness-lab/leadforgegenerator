import csv
import io
import pandas as pd
from flask import send_file


def export_to_csv():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Naam", "Adres", "Website", "Score"])
    writer.writerow(["Testbedrijf", "Straat 1", "http://example.com", "85"])
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode()),
        mimetype="text/csv",
        as_attachment=True,
        download_name="leads.csv"
    )


def export_to_excel():
    df = pd.DataFrame([{
        "Naam": "Testbedrijf",
        "Adres": "Straat 1",
        "Website": "http://example.com",
        "Score": 85
    }])
    output = io.BytesIO()
    df.to_excel(output, index=False)
    output.seek(0)
    return send_file(
        output,
        as_attachment=True,
        download_name="leads.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
