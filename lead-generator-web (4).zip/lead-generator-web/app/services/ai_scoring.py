def ai_lead_scoring(bedrijf):
    score = 50
    if "website" in bedrijf and bedrijf["website"]:
        score += 20
    if "email" in bedrijf and bedrijf.get("email"):
        score += 20
    return min(score, 100)
