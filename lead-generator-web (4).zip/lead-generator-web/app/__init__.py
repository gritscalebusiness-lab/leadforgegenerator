import os
import sentry_sdk
from flask import Flask
from app.extensions import db, migrate, login_manager, csrf, limiter, talisman
from app.config import config


def create_app(config_name='development'):
    app = Flask(__name__, 
                template_folder='templates',
                static_folder='static')
    
    app.config.from_object(config[config_name])
    
    sentry_dsn = app.config.get('SENTRY_DSN')
    if sentry_dsn and sentry_dsn.strip():
        sentry_sdk.init(dsn=sentry_dsn, traces_sample_rate=1.0)
    else:
        print("⚠️ Sentry DSN ontbreekt. Foutenlogging naar Sentry is uitgeschakeld.")
    
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)
    
    csp = {
        'default-src': ["'self'"],
        'script-src': [
            "'self'",
            "'unsafe-inline'",
            "https://js.stripe.com",
            "https://www.paypal.com",
            "https://cdn.jsdelivr.net"
        ],
        'style-src': [
            "'self'",
            "'unsafe-inline'",
            "https://fonts.googleapis.com"
        ],
        'font-src': [
            "'self'",
            "https://fonts.gstatic.com"
        ],
        'frame-src': [
            "https://js.stripe.com",
            "https://www.paypal.com"
        ],
        'connect-src': [
            "'self'",
            "https://api.stripe.com",
            "https://www.paypal.com",
            "https://api-m.paypal.com",
            "https://api-m.sandbox.paypal.com"
        ]
    }
    
    force_https = config_name == 'production'
    talisman.init_app(
        app,
        force_https=force_https,
        strict_transport_security=force_https,
        content_security_policy=csp,
        content_security_policy_nonce_in=['script-src']
    )
    
    @login_manager.user_loader
    def load_user(user_id):
        from app.models.user import User
        return User.query.get(int(user_id))
    
    from app.routes import auth_bp, leads_bp, teams_bp, payments_bp, main_bp
    from flask_login import current_user as flask_current_user
    
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(leads_bp, url_prefix='/leads')
    app.register_blueprint(teams_bp, url_prefix='/teams')
    app.register_blueprint(payments_bp, url_prefix='/payments')
    app.register_blueprint(main_bp)
    
    @app.errorhandler(404)
    def page_not_found(e):
        return app.jinja_env.get_template('404.html').render(current_user=flask_current_user), 404
    
    @app.errorhandler(500)
    def internal_error(e):
        return app.jinja_env.get_template('500.html').render(current_user=flask_current_user), 500
    
    with app.app_context():
        db.create_all()
    
    return app
