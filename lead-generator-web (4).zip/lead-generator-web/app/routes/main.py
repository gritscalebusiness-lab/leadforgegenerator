from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import current_user

main_bp = Blueprint('main', __name__)


@main_bp.route("/")
def home():
    return render_template("home.html")


@main_bp.route("/help")
def help():
    return render_template("help.html")


@main_bp.route("/settings", methods=["GET", "POST"])
def settings():
    if not current_user.is_authenticated:
        flash("Please log in first.")
        return redirect(url_for("auth.login"))

    if request.method == "POST":
        from app.extensions import db
        new_email = request.form.get("email")
        current_user.email = new_email
        db.session.commit()
        flash("Instellingen bijgewerkt!")
        return redirect(url_for("main.settings"))

    return render_template("settings.html", user=current_user)


@main_bp.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        name = request.form.get("name")
        email = request.form.get("email")
        message = request.form.get("message")
        print(f"[CONTACT] Bericht ontvangen van {name} ({email}): {message}")
        flash("Je bericht is verzonden, we nemen snel contact met je op.")
        return redirect(url_for("main.home"))
    return render_template("contact.html")


@main_bp.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404


@main_bp.errorhandler(500)
def internal_error(e):
    return render_template("500.html"), 500
