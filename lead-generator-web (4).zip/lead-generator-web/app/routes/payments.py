import os
import stripe
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app
from flask_login import login_required, current_user
from app.extensions import db, limiter, csrf
from app.utils.paypal_helpers import create_paypal_order, capture_paypal_order, verify_paypal_order
from app.models.user import ConsumedPayment

payments_bp = Blueprint('payments', __name__)

stripe.api_key = os.getenv("STRIPE_SECRET_KEY")


@payments_bp.route("/pricing")
def pricing():
    return render_template("pricing.html")


VALID_PLANS = {
    "business": {
        "price_id": "price_business",
        "name": "Business Plan",
        "amount": 79.00,
        "quota": 500
    },
    "enterprise": {
        "price_id": "price_enterprise",
        "name": "Enterprise Plan",
        "amount": 199.00,
        "quota": 5000
    },
}


def get_plan_from_amount(amount):
    amount = float(amount)
    for plan_key, plan_data in VALID_PLANS.items():
        if abs(plan_data["amount"] - amount) < 0.01:
            return plan_key, plan_data
    return None, None


@payments_bp.route("/checkout/<plan>")
@login_required
@limiter.limit("10 per hour")
def checkout(plan):
    if plan not in VALID_PLANS:
        flash("❌ Ongeldig plan.")
        return redirect(url_for("payments.pricing"))

    plan_data = VALID_PLANS[plan]
    provider = request.args.get('provider', 'stripe')

    if provider == 'paypal':
        return render_template("paypal_checkout.html", 
                             plan=plan, 
                             plan_data=plan_data,
                             paypal_client_id=current_app.config.get('PAYPAL_CLIENT_ID'))
    else:
        try:
            checkout_session = stripe.checkout.Session.create(
                payment_method_types=["card"],
                mode="subscription",
                line_items=[{
                    "price": plan_data["price_id"],
                    "quantity": 1
                }],
                customer_email=current_user.email,
                metadata={"plan": plan},
                success_url=url_for("payments.payment_success", _external=True) +
                "?session_id={CHECKOUT_SESSION_ID}&provider=stripe",
                cancel_url=url_for("payments.pricing", _external=True),
            )
            return redirect(checkout_session.url)
        except Exception as e:
            print(f"Stripe error: {e}")
            flash("⚠️ Er ging iets mis bij het opzetten van de betaling.")
            return redirect(url_for("payments.pricing"))


@payments_bp.route("/payment_success")
@login_required
def payment_success():
    provider = request.args.get("provider", "stripe")
    
    if provider == "paypal":
        order_id = request.args.get("order_id")
        if not order_id:
            flash("⚠️ Geen betalingssessie gevonden.")
            return redirect(url_for("leads.index"))
        
        existing_payment = ConsumedPayment.query.filter_by(payment_id=order_id).first()
        if existing_payment:
            flash("⚠️ Deze betaling is al gebruikt.")
            current_app.logger.warning(f"Attempted payment reuse: order_id={order_id} by user={current_user.id}")
            return redirect(url_for("leads.index"))
        
        verification = verify_paypal_order(order_id)
        if not verification.get("verified"):
            flash("⚠️ Betaling kon niet worden geverifieerd.")
            return redirect(url_for("leads.index"))
        
        order_details = verification.get("order", {})
        
        if order_details.get("status") != "COMPLETED":
            flash("⚠️ PayPal betaling is niet voltooid.")
            current_app.logger.warning(f"Incomplete PayPal order: order_id={order_id}, status={order_details.get('status')}")
            return redirect(url_for("leads.index"))
        try:
            amount_paid = float(order_details["purchase_units"][0]["amount"]["value"])
            payer_email = order_details.get("payer", {}).get("email_address", "").lower()
        except (KeyError, ValueError, IndexError):
            flash("⚠️ Kan betalingsbedrag niet verifiëren.")
            return redirect(url_for("leads.index"))
        
        if payer_email != current_user.email.lower():
            flash("⚠️ Betalings-email komt niet overeen met account.")
            current_app.logger.warning(f"Email mismatch: payer={payer_email}, user={current_user.email}")
            return redirect(url_for("leads.index"))
        
        plan, plan_data = get_plan_from_amount(amount_paid)
        if not plan:
            flash("⚠️ Ongeldig betalingsbedrag.")
            return redirect(url_for("leads.index"))
        
        current_user.payment_provider = "paypal"
        current_user.paypal_subscription_id = order_id
        quota = plan_data["quota"]
        
        consumed = ConsumedPayment(
            user_id=current_user.id,
            payment_id=order_id,
            provider="paypal",
            plan=plan,
            amount=amount_paid
        )
        db.session.add(consumed)
    else:
        session_id = request.args.get("session_id")
        if not session_id:
            flash("⚠️ Geen betalingssessie gevonden.")
            return redirect(url_for("leads.index"))
        
        existing_payment = ConsumedPayment.query.filter_by(payment_id=session_id).first()
        if existing_payment:
            flash("⚠️ Deze betaling is al gebruikt.")
            current_app.logger.warning(f"Attempted payment reuse: session_id={session_id} by user={current_user.id}")
            return redirect(url_for("leads.index"))

        session = stripe.checkout.Session.retrieve(session_id)
        
        if session.get("payment_status") != "paid":
            flash("⚠️ Betaling is niet voltooid.")
            current_app.logger.warning(f"Unpaid session: session_id={session_id}")
            return redirect(url_for("leads.index"))
        
        customer_email = session.get("customer_email", "").lower() or session.get("customer_details", {}).get("email", "").lower()
        if customer_email != current_user.email.lower():
            flash("⚠️ Betalings-email komt niet overeen met account.")
            current_app.logger.warning(f"Email mismatch: payer={customer_email}, user={current_user.email}")
            return redirect(url_for("leads.index"))
        
        current_user.payment_provider = "stripe"
        current_user.stripe_customer_id = session.get("customer")
        
        plan = session.get("metadata", {}).get("plan")
        if not plan or plan not in VALID_PLANS:
            flash("⚠️ Ongeldig plan in betalingssessie.")
            return redirect(url_for("leads.index"))
        
        quota = VALID_PLANS[plan]["quota"]
        
        consumed = ConsumedPayment(
            user_id=current_user.id,
            payment_id=session_id,
            provider="stripe",
            plan=plan,
            amount=VALID_PLANS[plan]["amount"]
        )
        db.session.add(consumed)

    current_user.plan = plan
    current_user.quota_limit = quota
    db.session.commit()

    flash("✅ Betaling succesvol! Je account is geüpgraded.")
    return redirect(url_for("leads.index"))


@payments_bp.route("/confirm_upgrade/<plan>", methods=["POST"])
@login_required
def confirm_upgrade(plan):
    flash("⚠️ Gebruik een betaalmethode (Stripe of PayPal) om te upgraden.")
    current_app.logger.warning(f"Deprecated confirm_upgrade route called by user {current_user.id}")
    return redirect(url_for("payments.pricing"))


@payments_bp.route("/thankyou")
def thankyou():
    return render_template("thankyou.html")


@payments_bp.route("/api/paypal/create-order", methods=["POST"])
@login_required
@limiter.limit("10 per hour")
@csrf.exempt
def create_paypal_order_api():
    try:
        data = request.json
        plan_key = data.get('plan')
        
        if not plan_key or plan_key not in VALID_PLANS:
            return jsonify({"error": "Invalid plan"}), 400
        
        plan_data = VALID_PLANS[plan_key]
        
        order = create_paypal_order(
            amount=plan_data["amount"],
            currency='EUR',
            description=f'LeadForge {plan_data["name"]}'
        )
        
        return jsonify(order), 200
        
    except Exception as e:
        current_app.logger.error(f"PayPal order creation error: {str(e)}")
        return jsonify({"error": str(e)}), 500


@payments_bp.route("/api/paypal/capture-order/<order_id>", methods=["POST"])
@login_required
@limiter.limit("10 per hour")
@csrf.exempt
def capture_paypal_order_api(order_id):
    try:
        existing_payment = ConsumedPayment.query.filter_by(payment_id=order_id).first()
        if existing_payment:
            return jsonify({"error": "Payment already consumed"}), 400
        
        order_data = capture_paypal_order(order_id)
        
        if order_data.get('status') == 'COMPLETED':
            try:
                amount_paid = float(order_data["purchase_units"][0]["payments"]["captures"][0]["amount"]["value"])
                payer_email = order_data.get("payer", {}).get("email_address", "").lower()
            except (KeyError, ValueError, IndexError):
                return jsonify({"error": "Cannot verify payment details"}), 400
            
            if payer_email != current_user.email.lower():
                current_app.logger.warning(f"PayPal email mismatch: payer={payer_email}, user={current_user.email}")
                return jsonify({"error": "Payer email mismatch"}), 403
            
            plan_key, plan_data = get_plan_from_amount(amount_paid)
            if not plan_key:
                return jsonify({"error": "Invalid payment amount"}), 400
            
            current_user.plan = plan_key
            current_user.quota_limit = plan_data["quota"]
            current_user.payment_provider = 'paypal'
            current_user.paypal_subscription_id = order_id
            
            consumed = ConsumedPayment(
                user_id=current_user.id,
                payment_id=order_id,
                provider="paypal",
                plan=plan_key,
                amount=amount_paid
            )
            db.session.add(consumed)
            db.session.commit()
            
            current_app.logger.info(f"PayPal payment successful for user {current_user.id}: {order_id}, plan: {plan_key}")
        
        return jsonify(order_data), 200
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"PayPal order capture error: {str(e)}")
        return jsonify({"error": str(e)}), 500


@payments_bp.route("/cancel")
def payment_cancel():
    flash("⚠️ Betaling geannuleerd.")
    return redirect(url_for("payments.pricing"))
