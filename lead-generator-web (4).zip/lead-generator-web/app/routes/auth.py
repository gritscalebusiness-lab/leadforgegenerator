from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, current_user, login_required
from app.extensions import db, limiter
from app.models.user import User
import re

auth_bp = Blueprint('auth', __name__)


def validate_email(email):
    if not email or len(email) > 120:
        return False
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(email_pattern, email) is not None


def validate_password(password):
    if not password or len(password) < 8:
        return False, "Wachtwoord moet minimaal 8 tekens bevatten."
    if len(password) > 128:
        return False, "Wachtwoord mag niet langer zijn dan 128 tekens."
    if not re.search(r'[A-Z]', password):
        return False, "Wachtwoord moet minimaal één hoofdletter bevatten."
    if not re.search(r'[a-z]', password):
        return False, "Wachtwoord moet minimaal één kleine letter bevatten."
    if not re.search(r'[0-9]', password):
        return False, "Wachtwoord moet minimaal één cijfer bevatten."
    return True, ""


@auth_bp.route("/login", methods=["GET", "POST"])
@limiter.limit("5 per minute")
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        
        if not validate_email(email):
            flash("❌ Ongeldig e-mailadres.")
            return render_template("login.html")
        
        if not password:
            flash("❌ Wachtwoord is verplicht.")
            return render_template("login.html")

        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user)
            flash("✅ Ingelogd!")
            return redirect(url_for("leads.index"))
        else:
            flash("❌ Ongeldige inloggegevens.")
    return render_template("login.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("✅ Uitgelogd.")
    return redirect(url_for("auth.login"))


@auth_bp.route("/register", methods=["GET", "POST"])
@limiter.limit("3 per hour")
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        
        if not username or len(username) < 3 or len(username) > 80:
            flash("❌ Gebruikersnaam moet tussen 3 en 80 tekens zijn.")
            return redirect(url_for("auth.register"))
        
        if not re.match(r'^[a-zA-Z0-9_-]+$', username):
            flash("❌ Gebruikersnaam mag alleen letters, cijfers, underscores en streepjes bevatten.")
            return redirect(url_for("auth.register"))
        
        if not validate_email(email):
            flash("❌ Ongeldig e-mailadres.")
            return redirect(url_for("auth.register"))
        
        is_valid, error_msg = validate_password(password)
        if not is_valid:
            flash(f"❌ {error_msg}")
            return redirect(url_for("auth.register"))

        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("❌ E-mail bestaat al.")
            return redirect(url_for("auth.register"))
        
        existing_username = User.query.filter_by(username=username).first()
        if existing_username:
            flash("❌ Gebruikersnaam bestaat al.")
            return redirect(url_for("auth.register"))

        user = User(username=username, email=email)
        user.set_password(password)

        db.session.add(user)
        db.session.commit()

        flash("🎉 Registratie geslaagd! Log nu in.")
        return redirect(url_for("auth.login"))

    return render_template("register.html")


@auth_bp.route("/reset_password", methods=["GET", "POST"])
@limiter.limit("3 per hour")
def reset_password():
    if request.method == "POST":
        email = request.form.get("email", "").strip()
        
        if not validate_email(email):
            flash("❌ Ongeldig e-mailadres.")
            return render_template("reset_password.html")
        
        user = User.query.filter_by(email=email).first()
        if user:
            flash("Resetlink is verzonden (simulatie).")
        else:
            flash("Geen account gevonden met dat e-mailadres.")
        return redirect(url_for("auth.login"))
    return render_template("reset_password.html")
