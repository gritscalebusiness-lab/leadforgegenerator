from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app.extensions import db
from app.services.ai_scoring import ai_lead_scoring
from app.services.export_service import export_to_csv, export_to_excel

leads_bp = Blueprint('leads', __name__)


@leads_bp.route("/index", methods=["GET", "POST"])
@login_required
def index():
    resultaten = []
    melding = None

    if request.method == "POST":
        zoekterm = request.form.get("zoekterm")
        aantal = int(request.form.get("aantal", 5))

        bedrijven = [{
            "title": f"Bedrijf {i}",
            "address": "Straat 1",
            "website": "http://example.com"
        } for i in range(aantal)]

        for b in bedrijven:
            score = ai_lead_scoring(b)
            resultaten.append({
                "naam": b["title"],
                "adres": b["address"],
                "website": b["website"],
                "score": score
            })

        current_user.search_count += 1
        db.session.commit()

    search_count = current_user.search_count
    quota_limit = current_user.quota_limit

    return render_template("index.html",
                           resultaten=resultaten,
                           melding=melding,
                           search_count=search_count,
                           quota_limit=quota_limit)


@leads_bp.route("/export/csv")
@login_required
def export_csv_route():
    return export_to_csv()


@leads_bp.route("/export/excel")
@login_required
def export_excel_route():
    return export_to_excel()


@leads_bp.route("/export_crm")
@login_required
def export_crm():
    flash("Je leads zijn succesvol geëxporteerd naar je CRM-systeem (simulatie).")
    return redirect(url_for("leads.index"))


@leads_bp.route("/lead_scoring")
@login_required
def lead_scoring():
    return render_template("lead_scoring.html", scored_leads=[])
