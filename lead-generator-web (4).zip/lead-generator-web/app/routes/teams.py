from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app.extensions import db
from app.models.user import User
from app.utils.team_helpers import create_team_id

teams_bp = Blueprint('teams', __name__)


@teams_bp.route("/create_team")
@login_required
def create_team():
    if current_user.plan not in ["business", "enterprise"]:
        flash("❌ Alleen beschikbaar voor Business en Enterprise.")
        return redirect(url_for("leads.index"))

    new_team_id = create_team_id()
    current_user.team_id = new_team_id
    current_user.is_admin = 1
    db.session.commit()

    flash("🎉 Team aangemaakt!")
    return redirect(url_for("teams.team_dashboard"))


@teams_bp.route("/team_dashboard")
@login_required
def team_dashboard():
    members = []
    if current_user.team_id:
        members = User.query.filter_by(team_id=current_user.team_id).all()
    return render_template("team_dashboard.html",
                           members=members,
                           is_admin=current_user.is_admin)


@teams_bp.route("/invite_member", methods=["POST"])
@login_required
def invite_member():
    email = request.form.get("email")
    user = User.query.filter_by(email=email).first()
    if user:
        user.team_id = current_user.team_id
        db.session.commit()
        flash(f"✅ {email} toegevoegd aan het team.")
    else:
        flash(f"❌ Geen gebruiker gevonden met e-mail {email}.")
    return redirect(url_for("teams.team_dashboard"))


@teams_bp.route("/analytics")
@login_required
def analytics():
    data = {
        "total_leads": 0,
        "searches_this_month": current_user.search_count,
        "team_members": 1
    }

    if current_user.team_id:
        data["team_members"] = User.query.filter_by(team_id=current_user.team_id).count()

    return render_template("analytics.html", data=data)
