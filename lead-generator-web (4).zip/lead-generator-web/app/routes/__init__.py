from app.routes.auth import auth_bp
from app.routes.leads import leads_bp
from app.routes.teams import teams_bp
from app.routes.payments import payments_bp
from app.routes.main import main_bp

__all__ = ['auth_bp', 'leads_bp', 'teams_bp', 'payments_bp', 'main_bp']
