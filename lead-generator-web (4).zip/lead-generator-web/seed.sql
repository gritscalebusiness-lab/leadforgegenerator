INSERT OR IGNORE INTO users (username, password, plan, search_count, quota_limit)
VALUES (
    'admin',
    '$pbkdf2:sha256:260000$GaCccn5Qy5lsuS5J$ae8a6b1f4a390dd78e13fc3b93e9799c2570f93f5d85f4d437a0f2ff1df34b0f',
    'enterprise',
    0,
    10000
);
